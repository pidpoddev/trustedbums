(() => {
  // chrome-extension/trustedbums/src/popup.ts
  var DEFAULT_API_BASE_URL = "https://vaoqvtxqvbptyxddpoju.supabase.co/functions/v1/extension-api-v1";
  var DEFAULT_SYNC_HOST = "https://clerk.trustedbums.com";
  var TRUSTED_BUMS_LOGIN_URL = "https://trustedbums.com/login";
  var TRUSTED_BUMS_APP_URL = new URL(TRUSTED_BUMS_LOGIN_URL).origin;
  var CLERK_SESSION_COOKIE_NAME = "__session";
  var CAPTURE_MESSAGE_TYPE = "TRUSTED_BUMS_CAPTURE_LINKEDIN_PAGE";
  var state = {
    authenticated: false,
    capture: null,
    context: null
  };
  var els = {
    status: document.querySelector("#status"),
    authPanel: document.querySelector("#authPanel"),
    signedInIdentity: document.querySelector("#signedInIdentity"),
    signIn: document.querySelector("#signIn"),
    signOut: document.querySelector("#signOut"),
    capturePanel: document.querySelector("#capturePanel"),
    profileName: document.querySelector("#profileName"),
    headline: document.querySelector("#headline"),
    selectedText: document.querySelector("#selectedText"),
    destination: document.querySelector("#destination"),
    note: document.querySelector("#note"),
    refreshContext: document.querySelector("#refreshContext"),
    sendCapture: document.querySelector("#sendCapture")
  };
  function setStatus(message, tone = "") {
    els.status.textContent = message;
    els.status.className = ["status", tone].filter(Boolean).join(" ");
  }
  function setBusy(isBusy) {
    els.refreshContext.disabled = isBusy;
    els.sendCapture.disabled = isBusy;
    els.signIn.disabled = isBusy;
    els.signOut.disabled = isBusy;
  }
  function truncate(value, maxLength) {
    const text = String(value || "").trim();
    return text.length > maxLength ? `${text.slice(0, maxLength - 1)}...` : text;
  }
  function getActiveLinkedInTab() {
    return new Promise((resolve, reject) => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs?.[0];
        if (!tab?.id || !tab.url) {
          reject(new Error("Open a LinkedIn profile or company page first."));
          return;
        }
        if (!/^https:\/\/www\.linkedin\.com\/(in|company)\//.test(tab.url)) {
          reject(new Error("This extension works on LinkedIn profile and company pages."));
          return;
        }
        resolve(tab);
      });
    });
  }
  function requestPageCapture(tabId) {
    return new Promise((resolve, reject) => {
      chrome.tabs.sendMessage(tabId, { type: CAPTURE_MESSAGE_TYPE }, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error("Reload the LinkedIn page, then try again."));
          return;
        }
        if (!response?.ok || !response.capture) {
          reject(new Error("Unable to read this LinkedIn page."));
          return;
        }
        resolve(response.capture);
      });
    });
  }
  function getCookies(details) {
    return new Promise((resolve) => {
      if (!chrome.cookies?.getAll) {
        resolve([]);
        return;
      }
      chrome.cookies.getAll(details, (cookies) => {
        resolve(cookies || []);
      });
    });
  }
  async function getSessionCookieToken() {
    const cookieUrls = [.../* @__PURE__ */ new Set([DEFAULT_SYNC_HOST, TRUSTED_BUMS_APP_URL])];
    for (const url of cookieUrls) {
      const cookies = await getCookies({ url, name: CLERK_SESSION_COOKIE_NAME });
      const sessionCookie = cookies.find((cookie) => cookie.value);
      if (sessionCookie?.value) {
        return sessionCookie.value;
      }
    }
    return null;
  }
  async function getSessionToken() {
    return getSessionCookieToken();
  }
  async function fetchApi(path, options = {}) {
    const token = await getSessionToken();
    if (!token) {
      throw new Error("Sign in to Trusted Bums first.");
    }
    const response = await fetch(`${DEFAULT_API_BASE_URL}${path}`, {
      ...options,
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        ...options.headers || {}
      }
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(payload.error || `Trusted Bums API returned ${response.status}.`);
    }
    return payload;
  }
  function destinationLabel(destination) {
    const prefix = destination.destinationType === "CUSTOMER_TARGET" ? "Target" : "Opportunity";
    const account = destination.targetAccountName || "Untitled account";
    const company = destination.companyName || destination.clientCompanyName;
    return company ? `${prefix}: ${account} (${company})` : `${prefix}: ${account}`;
  }
  function renderDestinations() {
    const opportunities = state.context?.destinations?.opportunities || [];
    const customerTargets = state.context?.destinations?.customerTargets || [];
    const destinations = [...opportunities, ...customerTargets];
    els.destination.replaceChildren();
    if (destinations.length === 0) {
      const option = new Option("No available destinations", "");
      els.destination.append(option);
      els.destination.disabled = true;
      els.sendCapture.disabled = true;
      return;
    }
    for (const destination of destinations) {
      const option = new Option(
        destinationLabel(destination),
        JSON.stringify({
          destinationType: destination.destinationType,
          id: destination.id
        })
      );
      els.destination.append(option);
    }
    els.destination.disabled = false;
    els.sendCapture.disabled = false;
  }
  function renderCapture() {
    els.profileName.textContent = state.capture?.profileName || "Unknown LinkedIn page";
    els.headline.textContent = state.capture?.headline || state.capture?.description || "No headline found";
    els.selectedText.textContent = state.capture?.selectedText || "None";
    els.capturePanel.classList.remove("hidden");
  }
  function renderAuth() {
    els.signedInIdentity.textContent = state.authenticated ? "Signed in to Trusted Bums." : "Sign in to load destinations.";
    els.signIn.classList.toggle("hidden", state.authenticated);
    els.signOut.classList.toggle("hidden", !state.authenticated);
  }
  async function refreshContext() {
    state.context = await fetchApi("/context");
    state.authenticated = true;
    renderAuth();
    renderDestinations();
  }
  function createClientRequestId(capture) {
    const randomPart = crypto.getRandomValues(new Uint32Array(1))[0].toString(16);
    return `tb-linkedin-${Date.now()}-${randomPart}-${capture.sourceUrl.slice(0, 48)}`.slice(0, 128);
  }
  async function sendCapture() {
    if (!state.capture) {
      throw new Error("No LinkedIn page capture is ready.");
    }
    const selectedDestination = JSON.parse(els.destination.value || "{}");
    if (!selectedDestination.destinationType || !selectedDestination.id) {
      throw new Error("Choose a destination first.");
    }
    const body = {
      destinationType: selectedDestination.destinationType,
      clientRequestId: createClientRequestId(state.capture),
      captureType: state.capture.captureType,
      sourceUrl: state.capture.sourceUrl,
      pageTitle: truncate(state.capture.pageTitle, 300),
      selectedText: truncate(state.capture.selectedText || state.capture.description, 4e3),
      note: truncate(els.note.value, 2e3),
      metadata: {
        extensionVersion: chrome.runtime.getManifest().version,
        profileName: state.capture.profileName,
        headline: state.capture.headline
      }
    };
    if (selectedDestination.destinationType === "OPPORTUNITY_REGISTRATION") {
      body.opportunityId = selectedDestination.id;
    } else {
      body.customerTargetId = selectedDestination.id;
    }
    await fetchApi("/page-captures", {
      method: "POST",
      body: JSON.stringify(body)
    });
  }
  async function initialize() {
    try {
      els.authPanel.classList.remove("hidden");
      renderAuth();
      const tab = await getActiveLinkedInTab();
      state.capture = await requestPageCapture(tab.id);
      renderCapture();
      try {
        await refreshContext();
        setStatus("Ready to send this page to Trusted Bums.", "success");
      } catch (error) {
        const message = error instanceof Error ? error.message : "Unable to load destinations.";
        const authHint = message.includes("Sign in") ? "Sign in to Trusted Bums in the browser, then reopen this extension." : message;
        setStatus(authHint, "error");
      }
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Unable to start extension.", "error");
    }
  }
  els.signIn.addEventListener("click", () => {
    chrome.tabs.create({ url: TRUSTED_BUMS_LOGIN_URL });
    setStatus("Sign in to Trusted Bums in the new tab, then reopen this extension.", "success");
  });
  els.signOut.addEventListener("click", () => {
    chrome.tabs.create({ url: TRUSTED_BUMS_APP_URL });
  });
  els.refreshContext.addEventListener("click", async () => {
    try {
      setBusy(true);
      await refreshContext();
      setStatus("Destinations refreshed.", "success");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Unable to refresh destinations.", "error");
    } finally {
      setBusy(false);
    }
  });
  els.sendCapture.addEventListener("click", async () => {
    try {
      setBusy(true);
      await sendCapture();
      setStatus("Sent to Trusted Bums as a draft capture.", "success");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Unable to send capture.", "error");
    } finally {
      setBusy(false);
    }
  });
  void initialize();
})();
